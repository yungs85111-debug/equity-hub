# EQUITY HUB — AI 코드 생성 마스터 프롬프트
# 버전: 1.2.0 (Skills_core v4.4.2 / Skills_ui v4.4.1 기반)
# 최종 업데이트: 2025-04

---

## ▣ 이 프롬프트의 사용법

이 문서를 **Cursor / Claude Code / ChatGPT** 등 AI 코드 생성 도구에 붙여넣고,
마지막 `[구현 요청]` 섹션에 만들고 싶은 화면을 지정하면 됩니다.

프롬프트 구성:
```
[1] 입력 파일 목록     ← 함께 첨부할 파일 안내
[2] 프로젝트 컨텍스트  ← 전체 시스템 개요
[3] 역할 분담 규칙     ← 각 파일의 권위 범위
[4] 공통 보정 규칙     ← 반드시 따라야 할 절대 규칙
[5] 화면별 구현 규칙   ← 화면 5종 각각의 세부 지침
[6] 구현 요청          ← 여기에 원하는 화면 입력
```

---

## [1] 입력 파일 목록 (모두 함께 첨부)

```
[데이터·계산]   Skills_core.md        v4.4.2
[UI 규칙]       Skills_ui.md          v4.4.1
[ref §5.2]      sector_hub.html
[ref §5.3-탭1]  sector_statboard.html
[ref §5.3-탭2]  stock_comparison.html
[ref §5.4]      equity_hub_detail.html
[ref §5.5]      indicator_popup.html
```

---

## [2] 프로젝트 컨텍스트

```
프로젝트명   : EQUITY HUB
컨셉         : "뇌동매매 하지 말고, 알고 투자하자"
타깃 사용자  : 투자 1~3년 차, 재무제표를 읽고 싶지만
               어디서 시작해야 할지 모르는 30~40대
교육 목적    : 복잡한 재무지표를 S/A/B/C 티어·바 게이지·비교 우위로
               변환해 누구나 빠르게 해석할 수 있도록 한다
데이터 원천  : SEC EDGAR (data.sec.gov) — API 키 불필요
분석 프레임  : 6대 코어 스탯 (수익성/성장성/안정성/효율성/밸류에이션/현금창출력)
섹터 분류    : GICS 11개 섹터
운영 모드    : demo (demo.db 조회) / live (EDGAR 실시간 수집)
DB           : SQLite (demo.db) — 스키마는 Skills_core.md §13 참조
```

---

## [3] 역할 분담 규칙 — 파일 간 권위 우선순위

| 항목 | 우선 참조 파일 | 비고 |
|------|---------------|------|
| 데이터 수집·API 호출 | Skills_core.md §1 | EDGAR 엔드포인트·헤더 규칙 |
| 지표 계산 공식 | Skills_core.md §2 | 6대 코어 스탯 계산식 |
| 티어 판정 로직 | Skills_core.md §3, §4 | 분위수 우선 → fallback 절대값 |
| DB 스키마 | Skills_core.md §13 | 테이블·컬럼·인덱스 |
| 파이프라인 순서 | Skills_core.md §10 | Step 1~13 |
| 화면 구조·레이아웃 | Skills_ui.md §5 + 해당 ref HTML | HTML이 레이아웃 비율·컴포넌트 스타일 기준 |
| 티어 컬러 | Skills_ui.md §12 (절대 우선) | ref HTML의 색상과 충돌 시 Skills §12 기준 강제 적용 |
| 교육 콘텐츠 문구 | Skills_ui.md §6 | 지표 정의·섹터 중요도 설명 |
| 인사이트 자동 생성 | Skills_ui.md §7 | 자동 생성 로직·문장 패턴 |
| 면책 표시 | Skills_ui.md §11 | 모든 화면 하단 고정 |

> ⚠️ 규칙 충돌 시: Skills_core.md > Skills_ui.md > ref HTML 순으로 우선 적용

---

## [4] 공통 보정 규칙 — 절대 준수

### 4-1. 티어 컬러 (Skills §12 — ref HTML과 다를 경우 이 기준 강제 적용)

```css
/* ── 티어 배지·텍스트 컬러 ── */
S티어   : #22C55E  (emerald-500)   /* 원본 일부 blue-500 → 수정 필수 */
A티어   : #60A5FA  (blue-400)      /* 원본 일부 emerald-500 → 수정 필수 */
B티어   : #F59E0B  (amber-500)     /* 원본 일부 slate-400(회색) → 수정 필수 */
C티어   : #EF4444  (red-500)       /* 원본 일부 orange-400 → 수정 필수 */
IMPAIRED: #7C3AED  (violet-600)
DEBT-FREE: #60A5FA (blue-400, A티어와 동일 — 의도적)
UNKNOWN  : #475569 (slate-600)

/* ── 6대 코어 스탯 축 컬러 ── */
수익성    : #3B82F6  (blue-500)
성장성    : #10B981  (emerald-500)
안정성    : #F59E0B  (amber-500)
효율성    : #8B5CF6  (violet-500)
밸류에이션: #EC4899  (pink-500)
현금창출력: #06B6D4  (cyan-500)

/* ── 레이아웃 ── */
페이지 배경: #020617 (slate-950 계열)
카드 배경  : #0f172a
테두리     : #1e293b
보조 텍스트: #94A3B8
```

### 4-2. 데모 모드 배너 (모든 화면 — Skills §0)

모든 화면 상단에 아래 배너를 반드시 포함한다.
ref HTML에 없는 경우도 추가한다.

```html
<!-- ✅ 데모 모드 배너 (Skills §0) — 모든 화면 필수 -->
<div class="w-full bg-slate-900/70 border-b border-amber-500/30 px-6 py-2
            flex items-center justify-between">
  <span class="text-[11px] font-bold text-amber-300 uppercase tracking-widest">
    📅 데이터 기준: {price_date} &nbsp;|&nbsp; 출처: SEC EDGAR
  </span>
  <span class="text-[10px] font-bold text-amber-400/70 uppercase tracking-widest">
    데모 버전 — 실시간 데이터가 아닙니다
  </span>
</div>
```

표시 조건: `DATA_MODE = "demo"` 일 때 항상 표시
`{price_date}`: prices 테이블에서 가장 최신 price_date 조회

### 4-3. 벤치마크 출처 표시 (섹터 정상 범위가 나오는 모든 위치 — Skills §0)

```
동적 계산 시 (§4.0 분위수 — n >= 10):
  "섹터 중앙값 {p50} (demo.db 실측 {n}개사, {fiscal_year}년 기준)"

Fallback 사용 시 (§4.1 절대값 — n < 10):
  "⚠️ 섹터 데이터 부족 — S&P 500 평균 기준 적용"
```

### 4-4. 면책 표시 (모든 화면 하단 고정 — Skills §11)

```html
<!-- ✅ 면책 표시 (Skills §11) — 모든 화면 하단 필수 -->
<footer class="py-8 px-6 border-t border-slate-800 bg-slate-950/50">
  <p class="text-sm text-slate-500 leading-relaxed max-w-4xl">
    <span class="font-bold text-slate-400">⚠️ DISCLAIMER:</span>
    본 대시보드는 교육 목적으로 제작되었습니다.
    투자 추천·매수·매도 의견이 아닙니다.
    재무 데이터 출처: SEC EDGAR (data.sec.gov)
    | 데이터 기준: {fiscal_year}년 연간 보고서 (10-K)
    | 주가 기준일: {price_date}
    | 벤치마크 출처: demo.db 실측 분위수 ({n}개사, {fiscal_year}년 기준)
    | 본 서비스는 데모 버전으로 실시간 데이터를 제공하지 않습니다.
    실제 투자 전 반드시 전문가 상담을 권장합니다.
  </p>
</footer>
```

### 4-5. {변수} 하드코딩 금지

```
{price_date}, {fiscal_year}, {sector_tier}, {n}, {avg_opm} 등
모든 {변수} 형식의 값은 하드코딩 금지.
반드시 런타임에 demo.db에서 조회한 실제 값으로 바인딩.

단, 아래 항목은 데모 고정값으로 처리 (실시간 API 호출 없음):
  - Market Pulse Indicators (VIX, US 10Y Yield 등)
  - HUD Ticker Footer (실시간 마퀴 주가)
  → [데모 고정값] 라벨을 UI에 표시
```

### 4-6. 게임 메타포 사용 원칙 (Skills §0 UI)

```
✅ 허용: S/A/B/C 티어 라벨, 바 게이지, 캐릭터 시트 레이아웃
✅ 허용: "이 섹터를 탐험하세요" 같은 가벼운 표현

❌ 금지: "팩션 선택", "클래스 선택" 등 게임 전용 용어
❌ 금지: 게임 전투/승패 메타포
```

### 4-7. 데이터 계산 핵심 규칙 요약

```python
# DR(부채비율) — Skills §1.3
DR = total_debt / total_equity  # book_liabilities 사용 금지

# FCF — Skills §10 Step 7
fcf = operating_cashflow - capex  # metrics 저장 전 반드시 계산

# 분위수 계산 — Skills §4.0
import numpy as np
qs = np.percentile(vals, [10, 25, 50, 75, 90])  # statistics.quantiles 금지

# sector_score — Skills §3.3
row = db.execute("SELECT common_score FROM scores ...").fetchone()
if row is None or row[0] is None: return None   # fetchone()[0] 직접 접근 금지
my_score = row[0]

# 티어 판정 우선순위 — Skills §4
# 1순위: DB에 동일 섹터 종목 10개 이상 → 실측 분위수 기준
# 2순위: 10개 미만 → §4.1 절대값 fallback
```

---

## [5] 화면별 구현 규칙

### §5.2 섹터 허브 (sector_hub.html)

```
레이아웃    : 3열 × 4행 그리드
행 배치     : 행1(IT/금융/헬스케어) → 행2(경기소비재/필수소비재/에너지)
              → 행3(산업재/유틸리티/소재) → 행4(커뮤니케이션/부동산/[전체보기])
섹터 티어   : 섹터 내 전체 종목 평균 total_score → 티어 변환 (런타임 계산)
종목 수     : EDGAR 해당 섹터 10-K 제출 기업 수 (런타임 조회)
카드 하단 바: S/A/B/C 비율 4색 분포 바 (emerald/blue/amber/red)
Market Pulse: 데모 고정값 처리 — [데모 고정값] 라벨 필수
```

### §5.3 탭1 섹터 스탯 보드 (sector_statboard.html)

```
6대 스탯 카드 : 각 카드에 스탯 축 컬러 적용 (§4-1 컬러 기준)
핵심 지표 3개 : Skills §6.2에서 {섹터명} 기준으로 자동 선택
지표 정의     : Skills §6.1에서 자동 선택
섹터 중요도   : Skills §6.3에서 자동 선택
벤치마크 출처 : 정상 범위 표시 시 {source} 반드시 함께 표시
티어 분포 바  : S/A/B/C 비율 4색 분포 바
인사이트 문장 : Skills §7.1 로직으로 자동 생성
탭 전환 버튼  : [섹터 이해하기] (활성) | [종목 비교 →]
```

### §5.3 탭2 종목 비교 (stock_comparison.html)

```
히트맵 테이블 : 시총 상위 10~20종목 × 6대 스탯 티어 셀
               테이블 헤더: 스탯 축 컬러(§4-1) 적용
               마지막 행  : 섹터 평균 티어
3Y CAGR 랭킹  : Skills §5.3 탭2 [C] — TOP 3
ROE×PER 산점도: Skills §5.3 탭2 [B] — 4분면 라벨 포함
인사이트 문장 : Skills §7.1 자동 생성 → {auto_sector_company_insight}
HUD Ticker    : 데모 고정값 처리 — [DEMO DATA] 라벨 필수
```

### §5.4 기업 상세 (equity_hub_detail.html)

```
캐릭터 시트 구조:
  - 프로필 카드    : {ticker}, {company_name}, {sector}, {exchange}
  - Overall 배지   : {overall_tier} (대형 이탤릭) + {total_score}점
  - 6대 코어 스탯 바: 스탯 축 컬러 적용, 클릭 → §5.5 팝업
  - KPI 4개 하단 바: 매출YoY / OPM / ROE / 순현금
  - 인사이트 패널  : Skills §7.2~7.3 자동 생성 (3개)
  - 교육 배너      : "투자 추천이 아닙니다" 강조 (탭·전문가 도구 아님 명시)

스탯 바 width 계산:
  TIER_SCORE = {S:100, A:75, B:50, C:25, IMPAIRED:0, UNKNOWN:null}
  바 width = tier_score / 100 * 100 (%)
```

### §5.5 지표 설명 팝업 (indicator_popup.html)

```
팝업 구조 (2컬럼):
  좌측: 현재 수치 + 섹터 평균/정상 범위 + 지표 정의(§6.1) + 주의사항
  우측: 벤치마크 바 차트 + 섹터 중요도(§6.3) + 버튼

티어 배지     : Skills §12 컬러 엄수 (S=emerald, A=blue)
벤치마크 출처 : {source} 정상 범위 옆에 반드시 표시
주의사항      : caution_text가 있는 지표에만 표시
INSIGHT_FULL_VIEW 버튼: 현재 버전 비활성(disabled) — 추후 구현
팝업 하단     : 축약형 면책 표시 포함
```

---

## [6] 구현 요청 — 오케스트레이션 방식 (전체 대시보드 한 번에)

### 전제 조건 (구현 시작 전 확인)

```
프레임워크 : React (Vite) + Tailwind CSS + React Router v6
백엔드     : Python Flask + SQLite (demo.db)
DB 연도    : 2023 (fiscal_year = 2023 기준)
반응형     : 모바일 대응 필수 (lg:ml-64 SideNav 패턴 유지)
포트       : Frontend 5173 / Backend 5000
```

---

### 오케스트레이션 지시

아래 STEP 1~6을 **순서대로** 구현해줘.
각 STEP 완료 시 반드시 "✅ STEP N 완료" 를 출력하고 다음 STEP으로 넘어갈 것.
이전 STEP에서 만든 파일·컴포넌트·DB 연결·컬러 시스템은 이후 모든 STEP에서 재사용할 것.
공통 보정 규칙 [4] 는 모든 STEP에 적용.

---

### STEP 1 — 공통 기반 구축

**목표:** 이후 모든 화면이 공유하는 뼈대를 먼저 만든다.

```
[1-A] 프로젝트 초기화
  - Vite + React + Tailwind CSS 세팅
  - React Router v6 라우팅 기본 구조 생성
  - 폴더 구조:
      /src
        /components   ← 공통 컴포넌트
        /pages        ← 화면별 컴포넌트
        /hooks        ← DB 호출 커스텀 훅
        /constants    ← 컬러·티어 상수
      /backend
        app.py        ← Flask API 진입점
        db.py         ← demo.db 연결·쿼리 헬퍼
        routes/       ← 엔드포인트별 라우터

[1-B] 공통 상수 파일 (constants/skills_config.ts)
  - 티어 컬러 맵 (Skills §12 기준 — [4-1] 규칙 그대로)
      TIER_COLOR = { S:'#22C55E', A:'#60A5FA', B:'#F59E0B', C:'#EF4444',
                     IMPAIRED:'#7C3AED', DEBT_FREE:'#60A5FA', UNKNOWN:'#475569' }
  - 스탯 축 컬러 맵
      STAT_COLOR = { profitability:'#3B82F6', growth:'#10B981',
                     stability:'#F59E0B',     efficiency:'#8B5CF6',
                     valuation:'#EC4899',     cash_power:'#06B6D4' }
  - 티어 점수 맵
      TIER_SCORE = { S:100, A:75, B:50, C:25, IMPAIRED:0 }
  - 6대 스탯 라벨 (한국어)
      STAT_LABEL = { profitability:'수익성', growth:'성장성',
                     stability:'안정성',    efficiency:'효율성',
                     valuation:'밸류에이션', cash_power:'현금창출력' }

[1-C] 공통 레이아웃 컴포넌트
  - <TopBar />       : EQUITY HUB 로고 + 네비 링크 + 알림 + 아바타
  - <SideNav />      : 4개 메뉴 (섹터허브/포트폴리오스쿼드/마켓인텔/아카데미)
                       활성 메뉴 = border-r-2 border-blue-500 bg-slate-900
  - <DemoBanner />   : [4-2] 데모 모드 배너 — 모든 페이지 상단 고정
  - <Disclaimer />   : [4-3] 면책 표시 — 모든 페이지 하단 고정
  - <Layout />       : TopBar + SideNav + DemoBanner + {children} + Disclaimer 조합

[1-D] demo.db 구축 스크립트 3종 (순서대로 실행)

  ① backend/init_db.py — 스키마 생성
    - Skills_core §13 스키마 그대로 실행
    - 테이블 7개: companies / financials / prices /
                  metrics / tiers / scores / insights
    - 인덱스 6개 포함
    - 실행: python init_db.py
    - 완료 메시지: "✅ demo.db 스키마 생성 완료"

  ② backend/fetch_edgar.py — EDGAR 데이터 수집 (live 파이프라인)
    - Skills_core §10 Step 1~12 순서 실행
    - 대상 종목: 부록 B 165개 전체
    - EDGAR rate limit 준수: 요청 간 100ms 대기
    - yfinance 주가 수집 포함 (최대 3회 재시도, 간격 2초)
    - 진행 상황 출력: "[{n}/{total}] {ticker} 수집 중..."
    - 완료 메시지: "✅ EDGAR 수집 완료 — {n}개 종목 저장"
    - 소요 시간 안내: 165개 기준 약 30~60분
    - DATA_MODE=live 환경변수 설정 시에만 실행

  ③ backend/seed_demo.py — 픽스처 데이터 삽입 (즉시 실행용)
    - 사전 수집된 demo_fixture.json → demo.db 일괄 INSERT
    - fetch_edgar.py 실행 없이 즉시 대시보드 확인 가능
    - 부록 B 165개 종목 2023년 10-K 기준 데이터 포함
    - 실행: python seed_demo.py
    - 완료 메시지: "✅ demo.db 준비 완료 — 165개 종목 ({fiscal_year}년 기준)"

  ⚠️ 권고 실행 순서:
    빠른 확인 : python init_db.py → python seed_demo.py
    실제 수집 : python init_db.py → python fetch_edgar.py

  ⚠️ §4.0 분위수 계산 조건:
    섹터 내 종목 n ≥ 10 → 실측 분위수 판정 (동적 벤치마크)
    섹터 내 종목 n < 10 → fallback 절대값 판정
    부록 B 165개 구성 기준: 모든 섹터 n ≥ 15 → 전 섹터 동적 벤치마크 작동

[1-E] Flask API 기반 (backend/app.py)
  - CORS 설정 (localhost:5173 허용)
  - 공통 에러 핸들러 (404 / 500)
  - /api/health 엔드포인트 → { status: 'ok', data_mode: 'demo', price_date: ... }
```

---

### STEP 2 — §5.2 섹터 허브

**참조:** sector_hub.html | Skills_ui §5.2 | Skills_core §3.3

```
[2-A] Flask API: /api/sectors (GET)
  - 부록C 쿼리 1번 실행
  - 응답: [ { sector, n, avg_score, overall_tier, n_s, n_a, n_b, n_c,
               s_pct, a_pct, b_pct, c_pct, price_date } ]
  - fiscal_year: query param (기본값 2023)

[2-B] React 페이지: /pages/SectorHub.tsx
  - sector_hub.html 레이아웃·컬러·HUD 장식 재현
  - 3열 × 4행 그리드 (§5.2 배치 규칙 — [5] 참조)
  - 섹터 카드 컴포넌트 <SectorCard />:
      · 티어 배지: TIER_COLOR 상수 사용
      · 하단 4색 분포 바: s_pct/a_pct/b_pct/c_pct
      · hover 효과 (bg-surface-container-high)
      · 클릭 → /sector/:sector_name 라우팅
  - Market Pulse 섹션: 데모 고정값 + [데모 고정값] 라벨
  - 로딩 상태: skeleton UI (카드 형태 pulse 애니메이션)
  - 에러 상태: 재시도 버튼 포함

[2-C] 라우팅 등록
  - / → <SectorHub />
```

---

### STEP 3 — §5.3 섹터 스탯 보드 (탭1 + 탭2)

**참조:** sector_statboard.html + stock_comparison.html | Skills_ui §5.3 | Skills_core §4

```
[3-A] Flask API: /api/sector/:sector_name (GET)
  - 탭1용: 섹터 평균 스탯 6개 + 티어 + 분위수 + source 문자열
           핵심 지표 3개 (§6.2에서 섹터별 선택)
           섹터 소개 문장 (§6.4)
           티어 분포 (n_s/n_a/n_b/n_c)
           인사이트 문장 (§7.1 로직 적용)
  - 탭2용 (쿼리 파라미터 tab=comparison):
           부록C 쿼리 2번 실행 → 시총 상위 20종목 + 6대 스탯 티어
           3Y CAGR TOP 3 (rev_3y_cagr 기준)

[3-B] React 페이지: /pages/SectorStatboard.tsx
  - URL: /sector/:sector_name
  - 탭 전환 상태: useState('understand' | 'compare')

  [탭1 — 섹터 이해하기]
    · 섹터명 + S-Tier 배지 헤더
    · 6대 스탯 카드 6개 (STAT_COLOR 적용, 티어 배지, 평균값, 분포 바)
    · 벤치마크 출처 표시: "섹터 중앙값 {p50} ({source})" — [4-3] 규칙
    · 핵심 지표 3개 카드 (정의·섹터 중요도·정상 범위·출처)
    · 티어 분포 4색 바 + 자동 인사이트 문장

  [탭2 — 종목 비교]
    · 히트맵 테이블: 6대 스탯 헤더에 STAT_COLOR 적용
                    티어 셀: TIER_COLOR 배지
                    마지막 행 = 섹터 평균
    · 3Y CAGR TOP 3 사이드 패널
    · ROE×PER 산점도: 4분면 라벨 포함
                     데이터 포인트 hover tooltip
    · 자동 인사이트 문장
    · 종목 행 클릭 → /company/:ticker 라우팅

[3-C] 라우팅 등록
  - /sector/:sector_name → <SectorStatboard />
```

---

### STEP 4 — §5.4 기업 상세

**참조:** equity_hub_detail.html | Skills_ui §5.4 | Skills_core §3

```
[4-A] Flask API: /api/company/:ticker (GET)
  - 부록C 쿼리 3번 실행
  - 응답: { ticker, company_name, sector, exchange, gics_industry,
             cik, market_cap, stock_price, price_change_1y,
             total_score, overall_tier, sector_percentile,
             tier_profitability, tier_growth, tier_stability,
             tier_efficiency,    tier_valuation, tier_cash_power,
             opm, roe, dr, icr, rev_yoy, per, ev_ebitda,
             fcf_margin, asset_turn, net_cash, price_date,
             insights: [ {title, body} × 3 ]  ← §7.2~7.3 생성
           }

[4-B] React 페이지: /pages/CompanyDetail.tsx
  - URL: /company/:ticker
  - equity_hub_detail.html 레이아웃 재현

  [프로필 카드 (col-span-8)]
    · {ticker} / {company_name} / {sector_label} / {exchange}
    · Power Level 바: total_score/100 width
    · Market Cap / P/E 수치

  [Overall 티어 배지 (col-span-4)]
    · {overall_tier} 대형 이탤릭 (tertiary #ffb786 색)
    · {total_score}점 / 섹터 내 상위 {sector_percentile}%

  [6대 코어 스탯 바 (col-span-7)]
    · 바 컬러: STAT_COLOR 적용
    · 바 width: TIER_SCORE[tier] / 100 * 100 %
    · 지표 라벨: OPM·ROE / 매출YoY / DR·ICR / 자산회전 / PER·EV/EBITDA / FCF Margin
    · 각 스탯 클릭 → <IndicatorPopup /> 열기 (STEP 5)

  [인사이트 + 교육 배너 (col-span-5)]
    · §7.2~7.3 자동 생성 인사이트 3개
    · "투자 추천이 아닙니다" 교육 배너

  [KPI 4개 하단 바]
    · 매출YoY / OPM / ROE / 순현금

[4-C] 라우팅 등록
  - /company/:ticker → <CompanyDetail />
```

---

### STEP 5 — §5.5 지표 설명 팝업

**참조:** indicator_popup.html | Skills_ui §5.5, §6 | Skills_core §4

```
[5-A] Flask API: /api/indicator/:ticker/:indicator_name (GET)
  - indicator_name: opm / roe / dr / cr / icr / per / pbr /
                    ev_ebitda / fcf_margin / rev_yoy / asset_turn 등
  - 응답: { indicator_name, indicator_fullname, value, tier,
             sector_avg, lo, hi, source,        ← 벤치마크 출처 포함
             percentile, indicator_definition,  ← §6.1
             sector_x_indicator_reason,          ← §6.3
             caution_text                        ← 해당 지표만
           }

[5-B] React 컴포넌트: /components/IndicatorPopup.tsx
  - 모달 오버레이 (backdrop-blur-xl bg-slate-950/40)
  - indicator_popup.html 레이아웃 재현

  [헤더]
    · {indicator_name} ({indicator_fullname}) + 티어 배지 (TIER_COLOR)
    · 닫기 버튼

  [본문 2컬럼]
    좌측:
      · 현재 수치 + 섹터 내 백분위
      · 섹터 평균 / 정상 범위 카드
        → source 문자열 amber 색으로 표시 — [4-3] 규칙
      · 지표 정의 (§6.1)
      · 주의사항 caution_text (있는 경우만)

    우측:
      · 벤치마크 바 차트 (5단 바, 현재값 포지션 강조)
      · 섹터 중요도 설명 (§6.3)
      · DATA_SHEET 버튼 / INSIGHT_FULL_VIEW 버튼 (disabled)

  [팝업 하단]
    · 축약형 면책 표시 + 데이터 기준일

[5-C] CompanyDetail에서 팝업 연결
  - 6대 스탯 바 클릭 시 selectedIndicator 상태 set
  - <IndicatorPopup indicator={selectedIndicator} onClose={...} />
```

---

### STEP 6 — 전체 라우팅 연결 및 마무리

```
[6-A] React Router 최종 라우팅 맵
  /                          → <SectorHub />
  /sector/:sector_name       → <SectorStatboard />
  /company/:ticker           → <CompanyDetail />
  *                          → 404 페이지

[6-B] 화면 간 연결 검증 (부록 A 흐름 기준)
  ✓ 섹터 허브 카드 클릭     → /sector/:sector_name
  ✓ 종목 비교 행 클릭       → /company/:ticker
  ✓ 기업 상세 스탯 바 클릭  → IndicatorPopup 모달
  ✓ 팝업 닫기               → CompanyDetail 복귀
  ✓ SideNav "섹터 허브"      → /

[6-C] 전체 일관성 최종 점검
  ✓ 모든 화면에 <DemoBanner /> 포함
  ✓ 모든 화면에 <Disclaimer /> 포함
  ✓ 티어 배지 컬러: TIER_COLOR 상수만 사용 (인라인 색상 금지)
  ✓ 스탯 바 컬러: STAT_COLOR 상수만 사용
  ✓ {변수} 하드코딩 없음 — 모두 API 응답값 바인딩
  ✓ 데모 고정값 항목에 [데모 고정값] 라벨 표시

[6-D] 실행 방법 README.md 생성
  - demo.db 초기화: python backend/init_db.py
  - 백엔드 실행  : python backend/app.py
  - 프론트 실행  : npm run dev
  - 접속          : http://localhost:5173
```

---

### 완료 기준

모든 STEP 완료 후 아래 체크리스트를 출력할 것:

```
[ ] demo.db 초기화 스크립트 정상 실행
[ ] /api/health 응답 확인
[ ] / → 섹터 허브 11개 카드 렌더링
[ ] 섹터 카드 클릭 → 섹터 스탯 보드 탭1 진입
[ ] [종목 비교 →] 탭 전환 → 히트맵 테이블 렌더링
[ ] 종목 행 클릭 → 기업 상세 캐릭터 시트 렌더링
[ ] 스탯 바 클릭 → 지표 팝업 모달 출력
[ ] 티어 컬러 전체 확인 (S=emerald / A=blue / B=amber / C=red)
[ ] 데모 배너 전체 화면 표시 확인
[ ] 면책 표시 전체 화면 표시 확인
```

---

## [부록 A] 전체 화면 흐름 요약

```
[홈] 섹터 허브 (sector_hub)
  ↓ 섹터 카드 클릭
[섹터 스탯 보드] (sector_statboard)
  ├─ 탭1: 섹터 이해하기
  └─ 탭2: 종목 비교 (stock_comparison)
       ↓ 종목 행 클릭
[기업 상세] (equity_hub_detail)
  ↓ 지표 클릭 또는 ⓘ 버튼
[지표 설명 팝업] (indicator_popup)
```

---

## [부록 B] demo.db 사전 적재 종목 165개 (Skills §1-bis 개정)

```
⚠️ 변경 이유:
   Skills_core §4.0: 섹터 내 n < 10 → fallback 강제 전환 (분위수 계산 불가)
   기존 50개 구성은 IT(10개)만 경계선, 나머지 10개 섹터 전부 fallback 상태
   → 165개로 확대, 모든 섹터 n ≥ 15 확보 → 전 섹터 동적 벤치마크 작동

섹터별 구성 (총 165개, 모두 S&P 500 / NASDAQ 100 구성 종목 기준)
──────────────────────────────────────────────────────────────
IT (20)
  기존 10: AAPL, MSFT, NVDA, GOOGL, META, AMZN, TSLA, ORCL, AMD, INTC
  추가 10: QCOM, TXN, MU, ADBE, CRM, NOW, SNOW, PLTR, DELL, HPQ

금융 (20)
  기존 5 : JPM, BAC, WFC, GS, MS
  추가 15: C, USB, TFC, PNC, COF, AXP, BLK, SCHW, ICE, CME,
           MET, PRU, AFL, ALL, AIG

헬스케어 (20)
  기존 5 : JNJ, UNH, PFE, ABBV, MRK
  추가 15: BMY, AMGN, GILD, CVS, CI, ELV, HCA, MDT, SYK,
           BSX, ZBH, ISRG, IQV, DGX, MCK

경기소비재 (20)
  기존 5 : HD, NKE, MCD, SBUX, TGT
  추가 15: LOW, TJX, BKNG, MAR, HLT, YUM, DRI, ROST,
           ORLY, AZO, BBY, F, GM, APTV, LVS

필수소비재 (15)
  기존 5 : PG, KO, PEP, WMT, COST
  추가 10: CL, GIS, K, HSY, MKC, CHD, SJM, CAG, TSN, HRL

에너지 (15)
  기존 3 : XOM, CVX, COP
  추가 12: EOG, MPC, PSX, VLO, PXD, HAL, SLB, BKR,
           OXY, DVN, FANG, MRO

산업재 (20)
  기존 5 : CAT, BA, HON, UPS, DE
  추가 15: GE, MMM, EMR, ETN, ROK, CARR, OTIS, LMT,
           RTX, NOC, GD, WM, RSG, FDX, CSX

유틸리티 (15)
  기존 3 : NEE, DUK, SO
  추가 12: AES, EXC, PCG, XEL, WEC, ES, ETR, PPL,
           CNP, AEE, CMS, PNW

소재 (15)
  기존 3 : LIN, APD, NEM
  추가 12: FCX, NUE, STLD, VMC, MLM, PPG, SHW, ECL,
           IFF, CE, ALB, MOS

커뮤니케이션 (15)
  기존 4 : DIS, NFLX, T, VZ
  추가 11: GOOGL(중복제외→CMCSA), CHTR, PARA, WBD,
           EA, TTWO, MTCH, ZM, IAC, FOXA, OMC

부동산 (15)
  기존 3 : AMT, PLD, SPG
  추가 12: EQIX, PSA, O, WY, ARE, VTR, WELL,
           EQR, AVB, MAA, UDR, CPT
──────────────────────────────────────────────────────────────

섹터별 종목 수 요약:
  IT(20) / 금융(20) / 헬스케어(20) / 경기소비재(20) / 필수소비재(15)
  에너지(15) / 산업재(20) / 유틸리티(15) / 소재(15) / 커뮤니케이션(15) / 부동산(15)
  합계: 190개 (GOOGL 중복 제거 후 실질 189개)

분위수 계산 충족 여부:
  전 섹터 n ≥ 15 → §4.0 동적 분위수 판정 작동
  fallback 발생 조건 (n < 10): 해당 섹터 없음 ✅
```

---

## [부록 C] 자주 쓰는 DB 쿼리 패턴

```python
# 섹터 허브: 섹터별 평균 총점 + 티어 분포
SELECT c.sector,
       COUNT(*)                                        AS n,
       AVG(sc.total_score)                             AS avg_score,
       SUM(CASE WHEN sc.overall_tier='S' THEN 1 ELSE 0 END) AS n_s,
       SUM(CASE WHEN sc.overall_tier='A' THEN 1 ELSE 0 END) AS n_a,
       SUM(CASE WHEN sc.overall_tier='B' THEN 1 ELSE 0 END) AS n_b,
       SUM(CASE WHEN sc.overall_tier='C' THEN 1 ELSE 0 END) AS n_c
FROM companies c
JOIN scores sc ON c.ticker = sc.ticker
WHERE sc.fiscal_year = ?
GROUP BY c.sector;

# 종목 비교: 시총 상위 N종목 + 6대 스탯 티어
SELECT c.ticker, c.name,
       p.market_cap,
       t.tier_profitability, t.tier_growth, t.tier_stability,
       t.tier_efficiency,    t.tier_valuation, t.tier_cash_power,
       sc.total_score, sc.overall_tier
FROM companies c
JOIN scores  sc ON c.ticker = sc.ticker AND sc.fiscal_year = ?
JOIN tiers   t  ON c.ticker = t.ticker  AND t.fiscal_year  = ?
JOIN prices  p  ON c.ticker = p.ticker  AND p.price_date   = ?
WHERE c.sector = ?
ORDER BY p.market_cap DESC
LIMIT 20;

# 기업 상세: 최신 연도 전체 지표
SELECT m.*, t.*, sc.total_score, sc.overall_tier, sc.sector_percentile
FROM metrics m
JOIN tiers t   ON m.ticker = t.ticker AND m.fiscal_year = t.fiscal_year
JOIN scores sc ON m.ticker = sc.ticker AND m.fiscal_year = sc.fiscal_year
WHERE m.ticker = ? AND m.fiscal_year = ?;

# 오늘의 종목 (Skills §8)
SELECT c.ticker, sc.total_score, p.price_change_pct
FROM companies c
JOIN scores  sc ON c.ticker = sc.ticker
JOIN tiers   t  ON sc.ticker = t.ticker AND sc.fiscal_year = t.fiscal_year
JOIN prices  p  ON c.ticker = p.ticker AND p.price_date = ?
WHERE sc.overall_tier IN ('S', 'A')
  AND t.tier_valuation IN ('S', 'A', 'B')
  AND p.price_change_pct < 0
ORDER BY sc.total_score DESC
LIMIT 1;
```

---

*EQUITY HUB Master Prompt v1.2.0 | Skills_core v4.4.2 + Skills_ui v4.4.1 | 5개 HTML ref 포함*
*[6] 구현 요청: 오케스트레이션 방식 (STEP 1~6 전체 대시보드 한 번에)*
*demo.db: 165개 종목 (전 섹터 n≥15, 동적 분위수 전 섹터 작동)*
*뇌동매매 하지 말고, 알고 투자하자*
